# Baseball Game Bot

### This is a slack bot that plays a number baseball game
#### There are two sides to this game - the Offensive side and the Defensive side

___

### Offensive Side

#### The bot has a three-digit number and the player has **10** chances to guess it correctly.
#### If the player hits a digit in the number in right order, it will be a strike. Or it would be a ball if it is just in the answer but with wrong order.

![Offensive Side](/baseballBot/Images/Offense)
___

### Defensive Side

#### The player has a number in mind and the bot has **10** chances to gues it correctly.
#### If the bot hits the number in right order, it's gonna be a strike. Or it would be a ball if it is just in the answer but with wrong order. 

![Defensive Side](/baseballBot/Images/Defense)
___

### I Need Help

#### For players who may not know how the game is played. Clicking on this button explains the rubrics of the game.

![I Need Help](/baseballBot/Images/I Need Help)